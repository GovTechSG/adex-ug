# https://pypi.org/project/paho-mqtt/
# pip3 install paho-mqtt
import paho.mqtt.client as mqtt
import ssl

host = "evx.adex.gov.sg"
port = 8883
ca = "YOUR/CA/PATH"
cert = "YOUR/CLIENT/CERT/PATH"
private = "YOUR/CLEINT/KEY/PATH"
passphrase_key = "YOUR_PASS_PHRASE"


# Define event callbacks, put your additional logic.
def on_connect(client, userdata, flags, rc):
    print("rc: " + str(rc))


def on_message(client, userdata, msg):
    print("Received message [topic]: " + msg.topic + " [QoS]:" + str(msg.qos) + " [payload]:" + str(msg.payload))


def on_subscribe(client, userdata, mid, granted_qos):
    print("Subscribed: " + str(mid) + " " + str(granted_qos))


def on_log(client, userdata, level, buf):
    print(buf)


# Define ssl context creator
def get_ssl_ctx():
    try:
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
        ssl_context.load_verify_locations(cafile=ca)
        ssl_context.load_cert_chain(certfile=cert, keyfile=private, password=passphrase_key)
        return ssl_context
    except Exception as e:
        print("exception get_ssl_ctc()")
        raise e


# Create a new client
mqttc = mqtt.Client()

# Assign event callbacks
mqttc.on_connect = on_connect
mqttc.on_message = on_message
mqttc.on_subscribe = on_subscribe

# Uncomment to enable debug messages
# mqttClient.on_log = on_log

# Setup tls
ssl_context = get_ssl_ctx()
mqttc.tls_set_context(context=ssl_context)

# Connect to ADEX
mqttc.connect(host, port)

# Start subscribe, with QoS level 0
mqttc.subscribe(topic="topic/hello/world", qos=0)

# Continue the network loop
mqttc.loop_forever()
