# https://pypi.org/project/paho-mqtt/
# pip3 install paho-mqtt
import paho.mqtt.client as mqtt
import ssl

host = "evx.adex.gov.sg"
port = 8883
ca = "YOUR/CA/PATH"
cert = "YOUR/CLIENT/CERT/PATH"
private = "YOUR/CLEINT/KEY/PATH"
passphrase_key = "YOUR_PASS_PHRASE"


# Define event callbacks, put your additional logic.
def on_connect(client, userdata, flags, rc):
    print("rc: " + str(rc))


def on_publish(client, userdata, mid):
    print("mid: " + str(mid))


def on_log(client, userdata, level, buf):
    print(buf)


def on_disconnect(client, userdata, rc):
    print("Disconnected: " + str(rc))


# Define ssl context creator
def get_ssl_ctx():
    try:
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
        ssl_context.load_verify_locations(cafile=ca)
        ssl_context.load_cert_chain(certfile=cert, keyfile=private, password=passphrase_key)
        return ssl_context
    except Exception as e:
        print("exception get_ssl_ctc()")
        raise e


# Create a new client
mqttc = mqtt.Client()

# Assign event callbacks
mqttc.on_connect = on_connect
mqttc.on_disconnect = on_disconnect
mqttc.on_publish = on_publish

# Uncomment to enable debug messages
# mqttClient.on_log = on_log

# Setup tls
ssl_context = get_ssl_ctx()
mqttc.tls_set_context(context=ssl_context)

# Connect to ADEX
mqttc.connect(host, port)

# Continue the network loop
mqttc.loop_start()

# Publish a message with QoS level 0, retained false
mqttc.publish(topic="topic/hello/world", qos=0, retain=False, payload="my message")

# Disconnect gracefully
mqttc.disconnect()
