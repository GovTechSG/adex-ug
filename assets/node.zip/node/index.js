#!/usr/bin/env node

var fs = require('fs')
var mqtt = require('mqtt')

const MQTTCLIENT = 'example1'
const CLIENTID = MQTTCLIENT + '-UUID' // Replace with desired client ID, 
    // CLIENTID has to be unique in the system. Appending a constant UUID after MQTTCLIENT is a good way.
 
const CFG = {
  mqtt: {
    url: 'mqtts://sdx.sensors.gov.sg:8883',  // MQTT broker end point
    options: {
      clientId: CLIENTID,
      ca: fs.readFileSync('cert/cert.pem'),  // CA file, replace content
      cert: fs.readFileSync('cert/client.pem'), // Client certificate file, replace content
      key: fs.readFileSync('cert/private.key'), // Client private key file, replace content
      passphrase: 'pRiVaTeKeYpAs5', // Replace private key passphrase
      connectTimeout: 1000, // 1000 milliseconds (1 second)
    }
  }
}

let client = mqtt.connect(CFG.mqtt.url, CFG.mqtt.options)

// Once connection is successful, publish the current timestamp to the designated topic,
// and then close the connection.
client.on('connect', _ => {
  const TOPIC = "example/full/path/to/topic"  // Replace
  client.publish(TOPIC, '{"ts":' + Date.now() + '"}', err => {
    if (err) {
      console.error('Failed to publish to ' + TOPIC + ', error: ' + err)
    }
    client.end()
  })
})
