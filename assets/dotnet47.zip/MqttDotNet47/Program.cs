﻿using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Formatter;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
namespace ConsoleApp1
{
    class Program
    {
        public static async Task Main(string[] args)
        {

            string broker = "evx.adex.gov.sg";
            var port = 8883;
            string clientId = "clientId";
            string topic = "clientId/new-topic";


            var mqttFactory = new MqttFactory();

            //read content of ca.pem
            var caCertPem = File.ReadAllBytes("ca.pem");

            //create CA certificate
            X509Certificate2 caCert = new X509Certificate2(caCertPem);


            /**
             *  Convert client.pem and private.key to client_pfx.pfx using openSSL command below:
             *  
             * 'openssl pkcs12 -inkey private-key.pem -in client.pem -export -out client_pfx.pfx'
             *  passphrase is clientKeyPassword
             *  export password is empty
             * 
             * **/

            // create client certificate from pfx and export password set
            X509Certificate2 clientCert = new X509Certificate2("client_pfx.pfx", "");

            // add the certificates to root store
            X509Store store = new X509Store(StoreName.Root, StoreLocation.CurrentUser);
            store.Open(OpenFlags.ReadWrite);
            X509Certificate2Collection collection = new X509Certificate2Collection();
            store.Add(caCert);
            store.Add(clientCert);
            store.Close();

            //configure tls options
            var tlsOptions = new MqttClientOptionsBuilderTlsParameters()
            {
                UseTls = true,
                SslProtocol = System.Security.Authentication.SslProtocols.Tls12,
                Certificates = new List<X509Certificate>()
                {
                    clientCert, caCert
                },
                CertificateValidationHandler = (certContext) => {

                    X509Chain chain = new X509Chain();
                    chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
                    chain.ChainPolicy.RevocationFlag = X509RevocationFlag.ExcludeRoot;
                    chain.ChainPolicy.VerificationFlags = X509VerificationFlags.NoFlag;
                    chain.ChainPolicy.VerificationTime = DateTime.Now;
                    chain.ChainPolicy.UrlRetrievalTimeout = new TimeSpan(0, 0, 0);
                   
                    // convert provided X509Certificate to X509Certificate2
                    var x5092 = new X509Certificate2(certContext.Certificate);
                    return chain.Build(x5092);
                }
            };

            using (IMqttClient mqttClient = mqttFactory.CreateMqttClient())
            {

                // configure mqtt client options
                var mqttClientOptions = new MqttClientOptionsBuilder()
                    .WithTcpServer(broker, port)
                    .WithCleanSession(true)
                    .WithClientId(clientId)
                    .WithTimeout(TimeSpan.FromSeconds(40))
                    .WithTls(tlsOptions)
                    .WithProtocolVersion(MqttProtocolVersion.V311)
                    .Build();

                try
                {
                    // This will throw an exception if the server is not available.                  
                    await mqttClient.ConnectAsync(mqttClientOptions, CancellationToken.None);

                    if (mqttClient.IsConnected)
                    {
                        Console.WriteLine("--- MQTT Client Connected ---");
                        //######### PUBLISH ###############

                        string samplePayload = "{ 'lightlevel': 499 }";

                        //configure message to publish
                        var message = new MqttApplicationMessageBuilder()
                            .WithTopic(topic)
                            .WithPayload(samplePayload)
                            .WithQualityOfServiceLevel(MQTTnet.Protocol.MqttQualityOfServiceLevel.AtMostOnce)
                            .Build();

                        await mqttClient.PublishAsync(message, CancellationToken.None);
                        Console.WriteLine("MQTT application message is published.");

                        // Send a clean disconnect to the server by calling _DisconnectAsync_. Without this the TCP connection
                        // gets dropped and the server will handle this as a non clean disconnect (see MQTT spec for details).
                        var mqttClientDisconnectOptions = mqttFactory.CreateClientDisconnectOptionsBuilder().Build();
                        await mqttClient.DisconnectAsync(mqttClientDisconnectOptions, CancellationToken.None);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception found :" + e.StackTrace);
                }
            }
        }
    }
}
