<?php

declare(strict_types=1);

require __DIR__ . '/vendor/autoload.php';

use PhpMqtt\Client\ConnectionSettings;
use PhpMqtt\Client\Examples\Shared\SimpleLogger;
use PhpMqtt\Client\Exceptions\MqttClientException;
use PhpMqtt\Client\MqttClient;
use Psr\Log\LogLevel;

// Create an instance of a PSR-3 compliant logger. For this example, we will also use the logger to log exceptions.
$logger = new SimpleLogger(LogLevel::INFO);
$broker = 'evx.adex.gov.sg';
$brokerTlsPort = 8883;

$userPath = $_SERVER['PWD'];
$clientCrtFilePath = $userPath . '/subCerts/client.pem';
$clientKeyFilePath = $userPath .'/subCerts/private.pem';
$caFilePath = $userPath . '/subCerts/ca.pem';

$clientKeyPassword = 'pRiVaTeKeYpAs5'; // replace 
$clientId = 'example1-UUID'; // replace
$topic = 'example/full/path/to/topic'; // replace


try {
    // Create a new instance of an MQTT client and configure it to use the shared broker host and port.
    $client = new MqttClient($broker, $brokerTlsPort, $clientId , MqttClient::MQTT_3_1, null, $logger);

    // Create and configure the connection settings as required.
    $connectionSettings = (new ConnectionSettings)
        ->setUseTls(true)
        ->setTlsCertificateAuthorityFile($caFilePath)
        ->setTlsClientCertificateFile($clientCrtFilePath)
        ->setTlsClientCertificateKeyFile($clientKeyFilePath)
        ->setTlsClientCertificateKeyPassphrase($clientKeyPassword);


    // Connect to the broker with the configured connection settings and with a clean session.
    $client->connect($connectionSettings, true);

    $client->subscribe($topic, function (string $topic, string $message, bool $retained) use ($logger, $client) {
        $logger->info('We received a {typeOfMessage} on topic [{topic}]: {message}', [
            'topic' => $topic,
            'message' => $message,
            'typeOfMessage' => $retained ? 'retained message' : 'message',
        ]);

        // If we want the client to stop listening for messages after getting the first message, uncomment the line below.
        // $client->interrupt();
    }, MqttClient::QOS_AT_MOST_ONCE);

    // Since subscribing requires to wait for messages, we need to start the client loop which takes care of receiving,
    // parsing and delivering messages to the registered callbacks. The loop will run indefinitely, until a message
    // is received, which will interrupt the loop.
    $client->loop(true);


    // Gracefully terminate the connection to the broker.
    $client->disconnect();
} catch (MqttClientException $e) {
    // MqttClientException is the base exception of all exceptions in the library. Catching it will catch all MQTT related exceptions.
    $logger->error('Connecting with TLS or publishing with QoS 0 failed. An exception occurred.', ['exception' => $e]);
}