package main

import (
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io/ioutil"
	"log"
	"net/url"
	"strconv"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"
)

var (
	mqttURL          = "mqtts://evx.adex.gov.sg:8883"
	pubClientId      = "pubClientId"
	pubKeyPassphrase = "******"
	subClientId      = "subClientId"
	subKeyPassphrase = "******"

	pubTopic = pubClientId + "/Test"
	subTopic = "GovTech-bQyfMwXZg/mqttclock"
)

func createTLSConfig(clientId, passphrase string) *tls.Config {
	// Read the CA certificate file.
	caPEM, err := ioutil.ReadFile(clientId + "/ca.pem")
	if err != nil {
		log.Fatal(err)
	}
	caCertPool := x509.NewCertPool()
	if ok := caCertPool.AppendCertsFromPEM(caPEM); !ok {
		log.Fatal("Failed to parse CA cert")
	}

	// Read the client certificate file.
	clientCertPEM, err := ioutil.ReadFile(clientId + "/client.pem")
	if err != nil {
		log.Fatal(err)
	}

	// Read the client key file. Since it's encrypted, we have to decrypt it first before we can use it.
	clientKeyPEM, err := ioutil.ReadFile(clientId + "/private.pem")
	if err != nil {
		log.Fatal(err)
	}
	clientKeyBlock, _ := pem.Decode(clientKeyPEM)
	clientKeyDER, err := x509.DecryptPEMBlock(clientKeyBlock, []byte(passphrase)) // Decrypt using passphrase.
	if err != nil {
		log.Fatal(err)
	}
	// Turn the decrypted key block back into PEM format so that we can use tls.X509KeyPair.
	clientKeyBlock.Bytes = clientKeyDER
	clientKeyBlock.Headers = nil
	clientKeyPEM = pem.EncodeToMemory(clientKeyBlock)

	// Create the client certificate from the public/private key pair.
	clientCert, err := tls.X509KeyPair(clientCertPEM, clientKeyPEM)
	if err != nil {
		log.Fatal(err)
	}

	log.Printf("Got TLS config for %s\n", clientId)
	return &tls.Config{
		Certificates: []tls.Certificate{clientCert},
		RootCAs:      caCertPool,
	}
}

func createClientOptions(clientId string, uri *url.URL, conf *tls.Config) *mqtt.ClientOptions {
	opts := mqtt.NewClientOptions()
	opts.SetClientID(clientId)
	opts.AddBroker(fmt.Sprintf("ssl://%s", uri.Host))
	opts.SetTLSConfig(conf)
	return opts
}

func connect(clientId string, uri *url.URL, conf *tls.Config) mqtt.Client {
	opts := createClientOptions(clientId, uri, conf)
	client := mqtt.NewClient(opts)
	token := client.Connect()
	for !token.WaitTimeout(1 * time.Second) {
	}
	if err := token.Error(); err != nil {
		log.Fatal(err)
	}
	log.Printf("Connected for %s\n", clientId)
	return client
}

func subscribe(uri *url.URL, topic string) {
	conf := createTLSConfig(subClientId, subKeyPassphrase)

	client := connect(subClientId, uri, conf)
	// Subscribe to the topic and print the formatted message payload when it arrives.
	client.Subscribe(topic, 0, func(client mqtt.Client, msg mqtt.Message) {
		log.Printf("* [%s] %s\n", msg.Topic(), string(msg.Payload()))
	})
}

func publish(uri *url.URL, topic, payload string) {
	conf := createTLSConfig(pubClientId, pubKeyPassphrase)

	client := connect(pubClientId, uri, conf)
	client.Publish(topic, 0, true, payload)
	log.Printf("Published %s to %s\n", topic, payload)
}

func main() {
	uri, err := url.Parse(mqttURL)
	if err != nil {
		log.Fatal(err)
	}
	// Subscribe before publishing so that we can see what we published.
	subscribe(uri, subTopic)

	// Publish the current UNIX timestamp as JSON data to the topic.
	payload := `{"ts":` + strconv.FormatInt(time.Now().Unix(), 10) + `}`
	publish(uri, pubTopic, payload)
}
