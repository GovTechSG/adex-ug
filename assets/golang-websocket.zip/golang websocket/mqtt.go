package main

import (
	"fmt"
	"log"
	"net/url"
	"strconv"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"
)

var (
	mqttURL      = "mqtts://evx.adex.gov.sg:8883"
	pubClientId  = "pubClientId" // replace with client id
	pubKeySecret = "******"      // replace with client secret
	subClientId  = "subClientId" // replace with client id
	subKeySecret = "******"      // replace with client secret

	pubTopic = pubClientId + "/Test"         // replace with pub topic
	subTopic = "GovTech-bQyfMwXZg/mqttclock" // replace with sub topic
)

func createClientOptions(clientKey string, clientKeyPassphrase string, uri *url.URL) *mqtt.ClientOptions {
	opts := mqtt.NewClientOptions()
	opts.SetUsername(clientKey)
	opts.SetPassword(clientKeyPassphrase)
	opts.AddBroker(fmt.Sprintf("wss://%s/ws", uri.Host))
	return opts
}

func connect(clientKey string, clientKeyPassphrase string, uri *url.URL) mqtt.Client {
	opts := createClientOptions(clientKey, clientKeyPassphrase, uri)
	client := mqtt.NewClient(opts)
	token := client.Connect()
	for !token.WaitTimeout(1 * time.Second) {
	}
	if err := token.Error(); err != nil {
		log.Fatal(err)
	}
	log.Printf("Connected for %s\n", clientKey)
	return client
}

func subscribe(uri *url.URL, topic string) {
	client := connect(subClientId, subKeySecret, uri)
	// Subscribe to the topic and print the formatted message payload when it arrives.
	client.Subscribe(topic, 0, func(client mqtt.Client, msg mqtt.Message) {
		log.Printf("* [%s] %s\n", msg.Topic(), string(msg.Payload()))
	})
}

func publish(uri *url.URL, topic, payload string) {
	client := connect(pubClientId, pubKeySecret, uri)
	client.Publish(topic, 0, true, payload)
	log.Printf("Published %s to %s\n", topic, payload)
}

func main() {
	uri, err := url.Parse(mqttURL)
	if err != nil {
		log.Fatal(err)
	}
	// Subscribe before publishing so that we can see what we published.
	subscribe(uri, subTopic)

	// Publish the current UNIX timestamp as JSON data to the topic.
	payload := `{"ts":` + strconv.FormatInt(time.Now().Unix(), 10) + `}`
	publish(uri, pubTopic, payload)
}
