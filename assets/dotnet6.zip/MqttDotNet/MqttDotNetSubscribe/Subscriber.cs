using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Formatter;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace MQTTSubscriber {

    public class Subscriber {

        public static async Task Main(string[] args)
        {

            string broker = "evx.adex.gov.sg";
            var port = 8883;
            string clientId = "clientId";
            string topic = "clientId/topic";


            var mqttFactory = new MqttFactory();

            //read content of ca.pem
            var caCertPem = File.ReadAllText(@"ca.pem");

            //create CA certificate
            X509Certificate2 caCert = X509Certificate2.CreateFromPem(caCertPem);

            /**
             *  Convert client.pem and private.key to client_pfx.pfx using openSSL command below:
             *  
             * 'openssl pkcs12 -inkey private-key.pem -in client.pem -export -out client_pfx.pfx'
             *  passphrase is the password used for private-key.pem
             *  export password is empty
             * 
             * **/

            //create client certificate from pfx and export password set
            X509Certificate2 clientCert = new X509Certificate2(@"client_pfx.pfx", "");

            //configure tls options
            var tlsOptions = new MqttClientOptionsBuilderTlsParameters()
            {
                UseTls = true,
                SslProtocol = System.Security.Authentication.SslProtocols.Tls12,
                Certificates = new List<X509Certificate>()
                {
                    clientCert, caCert
                },
                CertificateValidationHandler = (certContext) => {
                    X509Chain chain = new X509Chain();
                    chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
                    chain.ChainPolicy.RevocationFlag = X509RevocationFlag.ExcludeRoot;
                    chain.ChainPolicy.VerificationFlags = X509VerificationFlags.NoFlag;
                    chain.ChainPolicy.VerificationTime = DateTime.Now;
                    chain.ChainPolicy.UrlRetrievalTimeout = new TimeSpan(0, 0, 0);
                    chain.ChainPolicy.CustomTrustStore.Add(caCert);
                    chain.ChainPolicy.CustomTrustStore.Add(clientCert);
                    chain.ChainPolicy.TrustMode = X509ChainTrustMode.CustomRootTrust;

                    // convert provided X509Certificate to X509Certificate2
                    var x5092 = new X509Certificate2(certContext.Certificate);
                    return chain.Build(x5092);
                }
            };

            using (IMqttClient mqttClient = mqttFactory.CreateMqttClient())
            {

                var mqttClientOptions = new MqttClientOptionsBuilder()
                    .WithTcpServer(broker, port)
                    .WithCleanSession(true)
                    .WithClientId(clientId)
                    .WithTimeout(TimeSpan.FromSeconds(40))
                    .WithTls(tlsOptions)
                    .WithProtocolVersion(MqttProtocolVersion.V311)
 		    .WithKeepAlivePeriod(TimeSpan.FromSeconds(60))
                    .Build();

                try
                {
                    // Setup message handling before connecting so that queued messages
                    // are also handled properly. When there is no event handler attached all
                    // received messages get lost.
                    mqttClient.ApplicationMessageReceivedAsync += e =>
                    {
                      
                        string topic = e.ApplicationMessage.Topic;
                        string payload = Encoding.UTF8.GetString(e.ApplicationMessage.Payload);
                        Console.WriteLine($"Topic: {topic}. Message Received: {payload}");
                        return Task.CompletedTask;
                    };


                    // This will throw an exception if the server is not available.
                    await mqttClient.ConnectAsync(mqttClientOptions, CancellationToken.None);

                    if (mqttClient.IsConnected)
                    {
                        Console.WriteLine("--- MQTT Client Connected ---");

                        //######### SUBSCRIBE ###############
                        var mqttSubscribeOptions = mqttFactory.CreateSubscribeOptionsBuilder()
                            .WithTopicFilter(f => { f.WithTopic(topic); })
                            .Build();

                        await mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic(topic).Build());
                        Console.WriteLine("MQTT Subscribed.");

                        // Send a clean disconnect to the server by calling _DisconnectAsync_. Without this the TCP connection
                        // gets dropped and the server will handle this as a non clean disconnect (see MQTT spec for details).
                        var mqttClientDisconnectOptions = mqttFactory.CreateClientDisconnectOptionsBuilder().Build();

                        await mqttClient.DisconnectAsync(mqttClientDisconnectOptions, CancellationToken.None);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception found :" + e.StackTrace);
                }
            }
        }

    }

}